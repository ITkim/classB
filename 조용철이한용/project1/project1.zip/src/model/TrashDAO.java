package TrashEx;

public class TrashDTO{
	//�ʵ� /
	private int no;
	private 
	private
	private
	
	
	
}